Nova City RP - Pack Complet
-------------------------------
Ce pack contient :
- Interface de connexion
- Dashboard de gestion du bot
- Modules tickets, anti-raid, sanctions et configuration

Identifiant : blv_mathias470
Mot de passe : Soleil97@

À héberger sur un service Node.js avec Express ou Railway.

